// INICIALIZACIÓN DE VARIABLE CON EL INPUT PARA BUSCAR LAS MARCAS:
let inputSearch = document.getElementById('inputSearch');
// INICIALIZACIÓN DE CONTAINER EN EL QUE SE IMPRIMIRÁ LAS MARCAS:
let containerRowBrands = document.getElementById('containerRowBrand');
// FETCH PARA IMPRIMIR LAS MARCAS ACTUALES:
fetch("http://localhost:3000/brands")
.then((response) => response.json())
.then((brands) => {
    brands.forEach(brand => {
        // CONTAINER
        let boxBrands = document.createElement('div');
        boxBrands.classList.add('col-md-6', 'col-lg-3', 'd-flex', 'align-items-stretch', 'mb-5', 'mb-lg-0');
        // CONTENIDO HTML:
        boxBrands.innerHTML = `
        <div class="icon-box" data-aos="fade-up" data-aos-delay="100">
            <img src="${brand.logo}" class="img-fluid" alt="">
            <h4 class="title"><a href="">${brand.name}</a></h4>
            <p class="description">${brand.description}</p>
            <br>
            <button class="btn btn-primary w-100 btn-sm">Detalles</button>
        </div>`
        containerRowBrands.appendChild(boxBrands);
    });
})
inputSearch.addEventListener('keyup', function (event){
    let letter = '';
    letter += event.key;
    // FETCH PARA IMPRIMIR LAS MARCAS ACTUALES:
    fetch("http://localhost:3000/brands")
    .then((response) => response.json())
    .then((brands) => {
        let result = brands.filter(brand => {
            return brand.name.includes(letter) || brand.description.includes(letter);
        })
        result.forEach(brand => {
            // CONTAINER
            let boxBrands = document.createElement('div');
            boxBrands.classList.add('col-md-6', 'col-lg-3', 'd-flex', 'align-items-stretch', 'mb-5', 'mb-lg-0');
            // CONTENIDO HTML:
            boxBrands.innerHTML = `
            <div class="icon-box" data-aos="fade-up" data-aos-delay="100">
                <img src="${brand.logo}" class="img-fluid" alt="">
                <h4 class="title"><a href="">${brand.name}</a></h4>
                <p class="description">${brand.description}</p>
                <br>
                <button class="btn btn-primary w-100 btn-sm">Detalles</button>
            </div>`
            containerRowBrands.appendChild(boxBrands);
        })
    });
    })