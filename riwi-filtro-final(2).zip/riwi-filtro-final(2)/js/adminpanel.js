// ---------------------------------------- MIDDLEWARE ----------------------------------------
// INICIALIZACIÓN DE VARIABLE CON LA CONFIRMACIÓN DE INICIO DE SESIÓN:
let auth = localStorage.getItem('auth');
if(auth != 1){
    location.href = "../../index.html";
}
// ------------------------------------------------------------------ LOG OUT ------------------------------------------------------------------
// FUNCIÓN PARA CERRAR SESIÓN:
function logOut(){
    localStorage.clear();
}
// -----------------------------------------------------------------------------------------------------------------------------------------------
// CAMPO PARA INSERTAR EL ADMIN NAME:
let itemAdminName = document.getElementById('adminName');
// ADMIN NAME:
let adminName = localStorage.getItem('name');
// INSERTAR NAME:
itemAdminName.innerText = adminName;

// =========================================================== CRUD FUNCTIONS ============================================================
// ------------------------------------------ FUNCIÓN PARA LISTAR LOS ADMINISTRADORES ACTUALES -------------------------------------------
// INICIALIZACIÓN DE VARIABLE CON EL CONTAINER DE LA TABLA PARA INSERTAR LOS DATOS:
let containerTableAdmins = document.getElementById("containerAdminsTable");
// FETCH PARA IMPRIMIR LOS ADMINS ACTUALES:
fetch("http://localhost:3000/admins")
.then((response) => response.json())
.then((admins) =>{
    admins.forEach(admin => {
        // ROW:
        let rowAdmin = document.createElement('tr');
        containerTableAdmins.appendChild(rowAdmin);
        // ID:
        let idAdmin = document.createElement('td');
        idAdmin.innerText = admin.id;
        rowAdmin.appendChild(idAdmin);
        // NAME:
        let nameAdmin = document.createElement('td');
        nameAdmin.innerText = admin.name;
        rowAdmin.appendChild(nameAdmin);
        // EMAIL:
        let emailAdmin = document.createElement('td');
        emailAdmin.innerText = admin.email;
        rowAdmin.appendChild(emailAdmin);
        // BUTTON CONTAINER:
        let buttonContainer = document.createElement('td');
        rowAdmin.appendChild(buttonContainer);
        // DETAILS BUTTON:
        let buttonDetails = document.createElement('button');
        buttonDetails.classList.add('btn', 'btn-sm', 'btn-info', 'm-1');
        buttonDetails.setAttribute('data-bs-toggle','modal');
        buttonDetails.setAttribute('data-bs-target','#detailsModal');
        buttonDetails.innerText = 'Detalles';
        // EVENTO 'click' EN EL BOTÓN ' Detalles' PARA LLAMAR A LA FUNCIÓN Y EJECUTARLA:
        buttonDetails.addEventListener("click", function () {
            showDetails(admin.id, admin.name, admin.email);
        });
        buttonContainer.appendChild(buttonDetails);
        // EDIT BUTTON:
        let buttonEdit = document.createElement('button');
        buttonEdit.classList.add('btn', 'btn-sm', 'btn-warning');
        buttonEdit.setAttribute('data-bs-toggle','modal');
        buttonEdit.setAttribute('data-bs-target','#editModal');
        buttonEdit.innerText = 'Editar';
        // EVENTO 'click' EN EL BOTÓN 'Editar' PARA LLAMAR A LA FUNCIÓN Y EJECUTARLA:
        buttonEdit.addEventListener("click", function () {
            getUserInfo(admin.id, admin.name, admin.email);
        });
        buttonContainer.appendChild(buttonEdit);
        // DELETE BUTTON:
        let buttonDelete = document.createElement('button');
        buttonDelete.classList.add('btn', 'btn-sm', 'btn-danger', 'm-1');
        buttonDelete.innerText = 'Eliminar';
        // EVENTO 'click' EN EL BOTÓN 'Eliminar' PARA LLAMAR A LA FUNCIÓN Y EJECUTARLA:
        buttonDelete.addEventListener("click", function () {
            deleteUser(admin.id); // LLAMADO DE LA FUNCIÓN PARA ELIMINAR EL USUARIO
        });
        buttonContainer.appendChild(buttonDelete);
    });
})
// ------------------------------------------------------------ CREATE NEW ADMIN ---------------------------------------------------------
function createUser() {
    let newInputName = document.getElementById("newInputName").value;
    let newInputEmail = document.getElementById("newInputEmail").value;
    fetch("http://localhost:3000/admins")
    .then(response => response.json())
    .then((admins) => {
        let result = admins.filter(function(admin){
            return admin.email == newInputEmail;
        })
        if(result.length > 0){
            // SE LANZA UN WARNING INDICANDO QUE EL CORREO LA SE ENCUENTRA REGISTRADO:
            // MODAL CONTAINER:
            let modalContainerCreate = document.getElementById('modalContainerCreate');
            // WARNING CONTAINER:
            let warningContainer = document.createElement('div');
            modalContainerCreate.appendChild(warningContainer);
            // MESSAGE:
            let warningMessage = document.createElement('span');
            warningMessage.innerText = '¡El correo ya se encuentra registrado!';
            warningContainer.appendChild(warningMessage);
        }else{
            // SE CREA UN OBJETO CON LOS NUEVOS VALORES DE LOS ELEMENTOS:
            infoUpdated = {
                name: newInputName,
                email: newInputEmail,
                password : 'password'
            };
            // SE UTILIZA LA FUNCIÓN fetch() PARA COGER LA API Y ENVIARLE LOS DATOS ACTUALIZADOS DEL NUEVO USER:
            fetch("http://localhost:3000/admins", {
                method: "POST",
                headers: {
                "Content-Type": "application/json",
                },
                body: JSON.stringify(infoUpdated),
            }).then((response) => {
                console.log(response.ok);
                location.reload();
            });
        }
    })
};
// ------------------------------------------------------------ DETAILS ---------------------------------------------------------
function showDetails(id, name, email){
    // SE INICIALIZAN LAS VARIABLES CON LOS 'id' DE LOS ELEMENTOS EN LOS CUALES SE AÑADIRÁ LA INFO DEL USER:
    let adminNameDetails = document.getElementById('adminNameDetails');
    let adminId = document.getElementById('adminId');
    let adminEmail = document.getElementById('adminEmail');
    // SE AÑADIRÁ LA INFO DEL USER EN LOS RESPECTIVOS ELEMENTOS DEL HTML:
    adminNameDetails.innerText = name;
    adminId.innerText = id;
    adminEmail.innerText = email;
};
// ---------------------------------------------------------- EDIT ------------------------------------------------------------
// FUNCIÓN PARA LLEVAR LA INFO DEL USUARIO SELECCIONADO AL 'modal':
function getUserInfo(id, name, email) {
    // SE ENVÍA EL 'id' DEL USUARIO SELECCIONADO AL 'sessionStorage':
    localStorage.setItem("id", id);
    // SE INICIALIZAN LAS VARIABLES CON LOS 'id' DE LOS ELEMENTOS 'inputs' PARA PODER PASARLES LOS VALORES DE LOS USERS ABAJO:
    let inputName = document.getElementById("inputName");
    let inputEmail = document.getElementById("inputEmail");
    // SE AGREGAN LOS VALORES DE LOS USERS EN LOS INPUTS:
    inputName.value = name;
    inputEmail.value = email;
};

// FUNCIÓN PARA ACTUALIZAR LA INFO DEL USUARIO:
function editUser() {
    // SE INICIALIZA LA VARIABLE CON EL 'id' QUE FUE ENVIADO AL sessionStorage:
    let userId = localStorage.getItem("id");
    // SE INICIALIZAN LAS VARIABLES CON EL NUEVO VALOR DE LOS 'inputs':
    let inputName = document.getElementById("inputName").value;
    let inputEmail = document.getElementById("inputEmail").value;
    // SE CREA UN OBJETO CON LOS NUEVOS VALORES DE LOS INPUTS:
    infoUpdated = {
        name: inputName,
        email: inputEmail,
        password: "password"
    };
    // SE UTILIZA LA FUNCIÓN fetch() PARA COGER LA API Y ENVIARLE LOS DATOS ACTUALIZADOS DEL USER SELECCIONADO:
    fetch("http://localhost:3000/admins/" + userId, {
    method: "PUT",
    headers: {
        "Content-Type": "application/json",
    },
        body: JSON.stringify(infoUpdated),
    }).then((response) => {
        console.log(response.ok);
        location.reload();
    });
};
// ------------------------------------------------------------ DELETE ADMIN ---------------------------------------------------------
// FUNCIÓN PARA ELIMINAR:
function deleteUser(id) {
    // FUNCIÓN 'fetch()' PARA MANIPULAR EL OBJETO .json:
    fetch("http://localhost:3000/admins/" + id, {
        method: "DELETE",
        headers: {
            "Content-Type": "application/json",
    },
    })
    .then((result) => {
        return result.json();
    })
    .then((info) => {
        alert("Administrador eliminado: " + info.name);
        location.reload();
    });
}