// ------------------------------------------------------- LOGIN FUNCTION --------------------------------------------------------
function logIn(){
    //INICIALIZACIÓN DE VARIABLES CON LOS VALORES INGRESADOS POR EL USUARIO:
    let email = document.getElementById('inputLoginEmail').value;
    let password = document.getElementById('inputLoginPassword').value;
    // FUNCIÓN FETCH PARA CONSULTAR LA INFO EN EL JSON SERVER:
    fetch('http://localhost:3000/admins')
    .then((response) => response.json())
    .then((admin) => {
        let result = admin.filter(function(admin){
            return admin.email == email && admin.password == password;
        });
        // CONDICIONAL PARA COMPROBAR QUE SE ENCONTRÓ UN USUARIO VALIDO:
        if(result.length > 0){
            // SE ENVÍA LA INFORMACIÓN DEL USUARIO AL sessionStorage:
            localStorage.setItem('name', result[0].name);
            localStorage.setItem('email', result[0].email);
            localStorage.setItem('auth', 1);
            location.href = "./admin/index.html";
            return;
        }else{
            // SE MUESTRA UN WARNING:
            let containerLogInItems = document.getElementById('containerLogInItems');
            let warningContainer = document.createElement('div');
            warningContainer.classList.add('mt-4');
            warningContainer.setAttribute('id', 'warningAlert');
            containerLogInItems.appendChild(warningContainer);
            // MESSAGE:
            let warningText = document.createElement('span');
            warningText.innerText = "¡Correo o contraseña incorrectos!";
            warningContainer.appendChild(warningText);
        }
    });
};