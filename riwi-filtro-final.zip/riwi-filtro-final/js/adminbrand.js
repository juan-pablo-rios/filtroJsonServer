// ---------------------------------------- MIDDLEWARE ----------------------------------------
// INICIALIZACIÓN DE VARIABLE CON LA CONFIRMACIÓN DE INICIO DE SESIÓN:
let auth = localStorage.getItem('auth');
if(auth != 1){
    location.href = "../../index.html";
}
// ---------------------------------------------------------------- LOG OUT ----------------------------------------------------------------
// FUNCIÓN PARA CERRAR SESIÓN:
function logOut(){
    localStorage.clear();
}
// -------------------------------------------------------------------------------------------------------------------------------------------
// CAMPO PARA INSERTAR EL ADMIN NAME:
let itemAdminName = document.getElementById('adminName');
// ADMIN NAME:
let adminName = localStorage.getItem('name');
// INSERTAR NAME:
itemAdminName.innerText = adminName;
// =========================================================== CRUD FUNCTIONS ============================================================
// ------------------------------------------ FUNCIÓN PARA LISTAR LAS MARCAS ACTUALES -------------------------------------------
// INICIALIZACIÓN DE VARIABLE CON EL CONTAINER DE LA TABLA PARA INSERTAR LOS DATOS:
let containerBrandsTable = document.getElementById('containerBrandsTable');
// FETCH PARA IMPRIMIR LAS MARCAS ACTUALES:
fetch("http://localhost:3000/brands")
.then((response) => response.json())
.then((brands) => {
    brands.forEach(brand => {
        // ROW:
        let rowBrands = document.createElement('tr');
        containerBrandsTable.appendChild(rowBrands);
        // ID:
        let idBrands = document.createElement('td');
        idBrands.innerText = brand.id;
        rowBrands.appendChild(idBrands);
        // CONTAINER IMG:
        let containerImg = document.createElement('td');
        rowBrands.appendChild(containerImg);
        // IMG:
        let imgBrand = document.createElement('img');
        imgBrand.setAttribute('src', brand.logo);
        imgBrand.setAttribute('width', '100px');
        imgBrand.setAttribute('alt', 'Brand-Image');
        containerImg.appendChild(imgBrand);
        // NAME:
        let nameBrand = document.createElement('td');
        nameBrand.innerText = brand.name;
        rowBrands.appendChild(nameBrand);
        // LOCAL:
        let localBrand = document.createElement('td');
        localBrand.innerText = brand.local;
        rowBrands.appendChild(localBrand);
        // FLOOR:
        let floorBrand = document.createElement('td');
        floorBrand.innerText = brand.floor;
        rowBrands.appendChild(floorBrand);
        // SCHEDULE:
        let scheduleBrand = document.createElement('td');
        scheduleBrand.innerText = brand.schedule;
        rowBrands.appendChild(scheduleBrand);
        // WEBSITE CONTAINER:
        let containerWebsite = document.createElement('td');
        rowBrands.appendChild(containerWebsite);
        // WEBSITE:
        let websiteBrand = document.createElement('a');
        websiteBrand.setAttribute('href', brand.website);
        websiteBrand.innerText = 'Sitio Web';
        containerWebsite.appendChild(websiteBrand);
        // BUTTON CONTAINER:
        let buttonsContainer = document.createElement('td');
        rowBrands.appendChild(buttonsContainer);



        // DETAILS BUTTON:
        let buttonDetails = document.createElement('button');
        buttonDetails.classList.add('btn', 'btn-sm', 'btn-info', 'm-1');
        buttonDetails.setAttribute('data-bs-toggle','modal');
        buttonDetails.setAttribute('data-bs-target','#detailsModal');
        buttonDetails.innerText = 'Detalles';
        // EVENTO 'click' EN EL BOTÓN ' Detalles' PARA LLAMAR A LA FUNCIÓN Y EJECUTARLA:
        buttonDetails.addEventListener("click", function () {
            showDetailsBrand(brand.logo, brand.id, brand.name, brand.local, brand.floor, brand.schedule, brand.website, brand.description);
        });
        buttonsContainer.appendChild(buttonDetails);




        // EDIT BUTTON:
        let buttonEdit = document.createElement('button');
        buttonEdit.classList.add('btn', 'btn-sm', 'btn-warning', 'm-1');
        buttonEdit.setAttribute('data-bs-toggle','modal');
        buttonEdit.setAttribute('data-bs-target','#editModal');
        buttonEdit.innerText = 'Editar';
        // EVENTO 'click' EN EL BOTÓN 'Editar' PARA LLAMAR A LA FUNCIÓN Y EJECUTARLA:
        buttonEdit.addEventListener("click", function () {
            getBrandInfo(brand.id, brand.name, brand.local, brand.floor, brand.schedule, brand.website, brand.description, brand.logo);
        });
        buttonsContainer.appendChild(buttonEdit);



        // DELETE BUTTON:
        let buttonDelete = document.createElement('button');
        buttonDelete.classList.add('btn', 'btn-sm', 'btn-danger', 'm-1');
        buttonDelete.innerText = 'Eliminar';
        // EVENTO 'click' EN EL BOTÓN 'Eliminar' PARA LLAMAR A LA FUNCIÓN Y EJECUTARLA:
        buttonDelete.addEventListener("click", function () {
            deleteBrand(brand.id); // LLAMADO DE LA FUNCIÓN PARA ELIMINAR EL USUARIO
        });
        buttonsContainer.appendChild(buttonDelete);
    });

})
// ------------------------------------------------------------ CREATE NEW BRAND ---------------------------------------------------------
function createBrand() {
    // SE INICIALIZAN LAS VARIABLES CON LOS VALORES DE LOS INPUTS:
    let newInputName = document.getElementById("newInputName").value;
    let newInputLocal = document.getElementById("newInputLocal").value;
    let newInputFloor = document.getElementById("newInputFloor").value;
    let newInputSchedule = document.getElementById("newInputSchedule").value;
    let newInputWebsite = document.getElementById("newInputWebsite").value;
    let newInputDescription = document.getElementById("newInputDescription").value;
    let newInputLogo = document.getElementById("newInputLogo").value;
    fetch("http://localhost:3000/brands")
    .then(response => response.json())
    .then((brands) => {
        let result = brands.filter(function(brand){
            return brand.name == newInputName;
        })
        // CONDICIONAL PARA VALIDAR SI EL NOMBRE YA SE ENCUENTRA REGISTRADO:
        if(result.length > 0){
            // SE LANZA UN WARNING INDICANDO QUE EL CORREO LA SE ENCUENTRA REGISTRADO:
            // MODAL CONTAINER:
            let modalContainerCreate = document.getElementById('modalContainerCreate');
            // WARNING CONTAINER:
            let warningContainer = document.createElement('div');
            modalContainerCreate.appendChild(warningContainer);
            // MESSAGE:
            let warningMessage = document.createElement('span');
            warningMessage.innerText = '¡El nombre ya se encuentra registrado!';
            warningContainer.appendChild(warningMessage);
        }else{
            // SE CREA UN OBJETO CON LOS NUEVOS VALORES DE LOS ELEMENTOS:
            infoUpdated = {
                name: newInputName,
                local: newInputLocal,
                floor: newInputFloor,
                schedule: newInputSchedule,
                website: newInputWebsite,
                description: newInputDescription,
                logo: newInputLogo
            };
            // SE UTILIZA LA FUNCIÓN fetch() PARA COGER LA API Y ENVIARLE LOS DATOS ACTUALIZADOS DEL NUEVO USER:
            fetch("http://localhost:3000/brands", {
                method: "POST",
                headers: {
                "Content-Type": "application/json",
                },
                body: JSON.stringify(infoUpdated),
            }).then((response) => {
                console.log(response.ok);
                location.reload();
            });
        }
    })
};
// ---------------------------------------------------------- EDIT ------------------------------------------------------------
// FUNCIÓN PARA LLEVAR LA INFO DE LA MARCA SELECCIONADA AL 'modal':
function getBrandInfo(id, name, local, floor, schedule, website, description, logo) {
    // SE ENVÍA EL 'id' DE LA MARCA SELECCIONADA AL 'sessionStorage':
    localStorage.setItem("brandId", id);
    // SE INICIALIZAN LAS VARIABLES CON LOS 'id' DE LOS ELEMENTOS 'inputs' PARA PODER PASARLES LOS VALORES DE LAS MARCAS ABAJO:
    let inputName = document.getElementById("inputName");
    let inputLocal = document.getElementById("inputLocal");
    let inputFloor = document.getElementById("inputFloor");
    let inputSchedule = document.getElementById("inputSchedule");
    let inputWebsite = document.getElementById("inputWebsite");
    let inputDescription = document.getElementById("inputDescription");
    let inputLogo = document.getElementById("inputLogo");
    // SE AGREGAN LOS VALORES DE LAS MARCAS EN LOS INPUTS:
    inputName.value = name;
    inputLocal.value = local;
    inputFloor.value = floor;
    inputSchedule.value = schedule;
    inputWebsite.value = website;
    inputDescription.innerText = description;
    inputLogo.value = logo;
};
// FUNCIÓN PARA ACTUALIZAR LA INFO DEL USUARIO:
function editBrand() {
    // SE INICIALIZA LA VARIABLE CON EL 'id' QUE FUE ENVIADO AL localStorage:
    let brandId = localStorage.getItem("brandId");
    // SE INICIALIZAN LAS VARIABLES CON EL NUEVO VALOR DE LOS 'inputs':
    let inputName = document.getElementById("inputName").value;
    let inputLocal = document.getElementById("inputLocal").value;
    let inputFloor = document.getElementById("inputFloor").value;
    let inputSchedule = document.getElementById("inputSchedule").value;
    let inputWebsite = document.getElementById("inputWebsite").value;
    let inputDescription = document.getElementById("inputDescription").value;
    let inputLogo = document.getElementById("inputLogo").value;
    fetch("http://localhost:3000/brands")
    .then(response => response.json())
    .then((brands) => {
        let result = brands.filter(function(brand){
            return brand.name == inputName;
        })
        // CONDICIONAL PARA VALIDAR SI EL NOMBRE YA SE ENCUENTRA REGISTRADO:
        if(result.length > 0){
            // SE LANZA UN WARNING INDICANDO QUE EL NOMBRE YA SE ENCUENTRA REGISTRADO:
            // MODAL CONTAINER:
            let modalContainerEdit = document.getElementById('modalContainerEdit');
            // WARNING CONTAINER:
            let warningContainer = document.createElement('div');
            modalContainerEdit.appendChild(warningContainer);
            // MESSAGE:
            let warningMessage = document.createElement('span');
            warningMessage.innerText = '¡El nombre ya se encuentra registrado!';
            warningContainer.appendChild(warningMessage);
        }else{
            // SE CREA UN OBJETO CON LOS NUEVOS VALORES DE LOS INPUTS:
            infoUpdated = {
                name: inputName,
                local: inputLocal,
                floor: inputFloor,
                schedule: inputSchedule,
                website: inputWebsite,
                description: inputDescription,
                logo: inputLogo
            };
            // SE UTILIZA LA FUNCIÓN fetch() PARA COGER LA API Y ENVIARLE LOS DATOS ACTUALIZADOS DEL USER SELECCIONADO:
            fetch("http://localhost:3000/brands/" + brandId, {
            method: "PUT",
            headers: {
                "Content-Type": "application/json",
            },
                body: JSON.stringify(infoUpdated),
            }).then((response) => {
                console.log(response.ok);
                location.reload();
            });
        }
    })
};

// ------------------------------------------------------------ DETAILS ---------------------------------------------------------
function showDetailsBrand(image, id, name, local, floor, schedule, website, description){
    // SE INICIALIZAN LAS VARIABLES CON LOS 'id' DE LOS ELEMENTOS EN LOS CUALES SE AÑADIRÁ LA INFO DEL USER:
    let brandImage = document.getElementById('brandImage');
    let brandId = document.getElementById('brandId');
    let brandName = document.getElementById('brandName');
    let brandLocal = document.getElementById('brandlocal');
    let brandFloor = document.getElementById('brandFloor');
    let brandSchedule = document.getElementById('brandSchedule');
    let brandWebsite = document.getElementById('brandWebsite');
    let brandDescription = document.getElementById('brandDescription');
    // SE AÑADIRÁ LA INFO DEL USER EN LOS RESPECTIVOS ELEMENTOS DEL HTML:
    brandImage.setAttribute('src', image);
    brandId.innerText = id;
    brandName.innerText = name;
    brandLocal.innerText = local;
    brandFloor.innerText = floor;
    brandSchedule.innerText = schedule;
    brandWebsite.innerText = website;
    brandDescription.innerText = description;
};
// ------------------------------------------------------------ DELETE ADMIN ---------------------------------------------------------
// FUNCIÓN PARA ELIMINAR:
function deleteBrand(id) {
    // FUNCIÓN 'fetch()' PARA MANIPULAR EL OBJETO .json:
    fetch("http://localhost:3000/brands/" + id, {
        method: "DELETE",
        headers: {
            "Content-Type": "application/json",
    },
    })
    .then((result) => {
        return result.json();
    })
    .then((info) => {
        alert("Administrador eliminado: " + info.name);
        location.reload();
    });
}