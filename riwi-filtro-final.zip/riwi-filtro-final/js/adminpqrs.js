// ---------------------------------------- MIDDLEWARE ----------------------------------------
// INICIALIZACIÓN DE VARIABLE CON LA CONFIRMACIÓN DE INICIO DE SESIÓN:
let auth = localStorage.getItem('auth');
if(auth != 1){
    location.href = "../../index.html";
}
// ------------------------------------------------------------------ LOG OUT ------------------------------------------------------------------
// FUNCIÓN PARA CERRAR SESIÓN:
function logOut(){
    localStorage.clear();
}
// -----------------------------------------------------------------------------------------------------------------------------------------------
// CAMPO PARA INSERTAR EL ADMIN NAME:
let itemAdminName = document.getElementById('adminName');
// ADMIN NAME:
let adminName = localStorage.getItem('name');
// INSERTAR NAME:
itemAdminName.innerText = adminName;