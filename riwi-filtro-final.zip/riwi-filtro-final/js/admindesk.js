// ---------------------------------------- MIDDLEWARE ----------------------------------------
// INICIALIZACIÓN DE VARIABLE CON LA CONFIRMACIÓN DE INICIO DE SESIÓN:
let auth = localStorage.getItem('auth');
if(auth != 1){
    location.href = "../index.html";
}

// ------------------------------------------------------------------ LOG OUT ------------------------------------------------------------------
// FUNCIÓN PARA CERRAR SESIÓN:
function logOut(){
    // MODIFICACIÓN DE LA AUTORIZACIÓN EN EL sessionStorage:
    localStorage.setItem('auth', 0);
    let auth = localStorage.getItem('auth');
    if(auth != 1){
        location.href = '../index.html';
    }
}
// -----------------------------------------------------------------------------------------------------------------------------------------------
// CAMPO PARA INSERTAR EL ADMIN NAME:
let itemAdminName = document.getElementById('adminName');
// ADMIN NAME:
let adminName = localStorage.getItem('name');
// INSERTAR NAME:
itemAdminName.innerText = adminName;
// ------------------------------------------------------------ FUNCTION LENGTH ------------------------------------------------------------
function endPointsLength(){
    // INICIALIZACIÓN DE VARIABLES DÓNDE SE INSERTARÁ EL LENGTH DE CADA ENDPOINT:
    let adminLengthItem = document.getElementById('adminLength');
    let brandLengthItem = document.getElementById('brandLength');
    let pqrsLengthItem = document.getElementById('pqrsLength');
    let adminLength = 0;
    let brandLength = 0;
    let pqrsLength = 0;
    // FETCH ADMINS:
    fetch("http://localhost:3000/admins")
    .then((response) => response.json())
    .then((admins) => {
        adminLength = admins.length;
        adminLengthItem.innerText = adminLength;
    });
    // FETCH BRANDS:
    fetch("http://localhost:3000/brands")
    .then((response) => response.json())
    .then((brands) => {
        brandLength = brands.length;
        brandLengthItem.innerText = brandLength;
    })
    // FETCH BRANDS:
    fetch("http://localhost:3000/pqrs")
    .then((response) => response.json())
    .then((pqrs) =>{
        pqrsLength = pqrs.length;
        pqrsLengthItem.innerText = pqrsLength;
    })
}
endPointsLength();